package gna;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * A number of JUnit tests for Solver.
 *
 * Feel free to modify these test to check additional properties.
 */
public class SolverTest {
  
  @Test
  public void test() {
  }
}
